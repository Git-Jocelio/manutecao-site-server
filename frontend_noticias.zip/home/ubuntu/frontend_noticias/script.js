// script.js

document.addEventListener('DOMContentLoaded', () => {
    // 1. Configuração
    // A rota base é /api, e o recurso é /noticias, conforme o index.js e noticia.routes.js
    // A porta é 3000, conforme o .env
    const API_BASE_URL = 'http://localhost:3000/api/noticias'; 

    // Elementos do DOM
    const newsForm = document.getElementById('news-form');
    const newsTableBody = document.querySelector('#news-table tbody');
    const newsIdInput = document.getElementById('news-id');
    const tituloInput = document.getElementById('titulo');
    const linkInput = document.getElementById('link');
    const postagemInput = document.getElementById('postagem');
    const exibirInput = document.getElementById('exibir');
    const imageInput = document.getElementById('image');
    const currentImageInfo = document.getElementById('current-image-info');
    const submitButton = document.getElementById('submit-button');
    const cancelButton = document.getElementById('cancel-button');

    // 2. Funções de Utilidade
    function resetForm() {
        newsForm.reset();
        newsIdInput.value = '';
        currentImageInfo.textContent = '';
        submitButton.textContent = 'Adicionar Notícia';
        cancelButton.style.display = 'none';
    }

    function formatDateForInput(dateString) {
        // Converte a data do formato ISO (YYYY-MM-DDTHH:mm:ss.sssZ) para YYYY-MM-DD
        if (!dateString) return '';
        return dateString.split('T')[0];
    }

    function formatDateForDisplay(dateString) {
        // Formata a data para exibição na tabela
        if (!dateString) return 'N/A';
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('pt-BR', options);
    }

    // 3. Funções de Comunicação com a API (CRUD)

    // GET: Buscar e exibir todas as notícias
    async function fetchNews() {
        try {
            // O backend está filtrando por exibir = TRUE, mas para manutenção, queremos todas.
            // Se o backend não tiver uma rota GET ALL sem filtro, esta rota pode não retornar todas as notícias.
            // Assumindo que a rota GET /noticias retorna todas as notícias para o painel de administração.
            const response = await fetch(API_BASE_URL);
            if (!response.ok) {
                throw new Error('Erro ao buscar notícias: ' + response.statusText);
            }
            const news = await response.json();
            renderNewsTable(news);
        } catch (error) {
            console.error('Erro ao buscar notícias:', error);
            alert('Não foi possível carregar as notícias. Verifique se o servidor está rodando na porta 3000 e se a rota /api/noticias está acessível.');
        }
    }

    // Renderizar a tabela com as notícias
    function renderNewsTable(news) {
        newsTableBody.innerHTML = ''; // Limpa a tabela
        if (news.length === 0) {
            newsTableBody.innerHTML = '<tr><td colspan="6">Nenhuma notícia encontrada.</td></tr>';
            return;
        }

        news.forEach(item => {
            const row = newsTableBody.insertRow();
            row.innerHTML = `
                <td>${item.idnoticia}</td>
                <td>${item.titulo}</td>
                <td><a href="${item.link}" target="_blank">Ver Link</a></td>
                <td>${formatDateForDisplay(item.postagem)}</td>
                <td>${item.exibir ? 'Sim' : 'Não'}</td>
                <td class="action-buttons">
                    <button class="edit-btn" data-id="${item.idnoticia}">Editar</button>
                    <button class="delete-btn" data-id="${item.idnoticia}">Excluir</button>
                </td>
            `;
        });
    }

    // POST/PUT: Enviar formulário (Criar ou Atualizar)
    async function handleSubmit(event) {
        event.preventDefault();

        const id = newsIdInput.value;
        const isUpdate = !!id;
        let url = API_BASE_URL;
        let method = 'POST';

        // O backend usa `multer` e espera um `FormData` para lidar com o upload de arquivo.
        const formData = new FormData();
        formData.append('titulo', tituloInput.value);
        formData.append('link', linkInput.value);
        formData.append('postagem', postagemInput.value);
        // O valor do checkbox deve ser 'true' ou 'false' (string) para o backend
        formData.append('exibir', exibirInput.checked ? 'true' : 'false');

        // Se for criação ou se um novo arquivo foi selecionado na edição
        if (!isUpdate || imageInput.files.length > 0) {
            // O campo no backend é 'imagem'
            formData.append('imagem', imageInput.files[0]);
        }
        
        // Se for atualização, o PUT não espera o campo 'imagem' no corpo, apenas os outros campos.
        // O backend de PUT não está tratando upload de imagem.
        // Para simplificar, vamos manter o PUT enviando apenas JSON, e o POST enviando FormData.
        // **Atenção:** O backend de PUT não está preparado para receber FormData com arquivo.
        // Se o usuário quiser atualizar a imagem, ele terá que usar a rota POST (criar) ou
        // o backend de PUT precisaria ser ajustado para receber FormData.
        // Como o PUT no seu código só espera JSON, vamos enviar JSON para o PUT.

        let bodyData;
        let headers = {};

        if (isUpdate) {
            // Se for atualização, enviamos JSON (sem arquivo)
            url = `${API_BASE_URL}/${id}`;
            method = 'PUT';
            bodyData = {
                titulo: tituloInput.value,
                link: linkInput.value,
                postagem: postagemInput.value,
                exibir: exibirInput.checked, // Booleano
            };
            headers['Content-Type'] = 'application/json';
        } else {
            // Se for criação, enviamos FormData (com arquivo)
            method = 'POST';
            bodyData = formData;
            // Não definimos Content-Type para FormData, o navegador faz isso automaticamente
        }


        try {
            const response = await fetch(url, {
                method: method,
                headers: headers,
                body: isUpdate ? JSON.stringify(bodyData) : bodyData,
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Erro ao ${isUpdate ? 'atualizar' : 'criar'} notícia: ${response.statusText}. Detalhes: ${errorText}`);
            }

            // Sucesso
            alert(`Notícia ${isUpdate ? 'atualizada' : 'criada'} com sucesso!`);
            resetForm();
            fetchNews(); // Recarrega a lista
        } catch (error) {
            console.error(`Erro ao ${isUpdate ? 'atualizar' : 'criar'} notícia:`, error);
            alert(`Erro ao ${isUpdate ? 'atualizar' : 'criar'} notícia. Verifique o console.`);
        }
    }

    // DELETE: Excluir notícia
    async function deleteNews(id) {
        if (!confirm('Tem certeza que deseja excluir esta notícia?')) {
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/${id}`, {
                method: 'DELETE',
            });

            if (response.ok) { // O backend retorna 200 OK
                alert('Notícia excluída com sucesso!');
                fetchNews(); // Recarrega a lista
            } else if (response.status === 404) {
                alert('Notícia não encontrada.');
            } else {
                throw new Error('Erro ao excluir notícia: ' + response.statusText);
            }
        } catch (error) {
            console.error('Erro ao excluir notícia:', error);
            alert('Erro ao excluir notícia. Verifique o console.');
        }
    }

    // Editar notícia (Preenche o formulário)
    async function editNews(id) {
        // O backend não tem uma rota GET /noticias/:id, mas a rota GET /noticias retorna todas.
        // Vamos buscar todas e encontrar a notícia pelo ID localmente.
        // O ideal seria ter uma rota GET /noticias/:id no backend.
        try {
            const response = await fetch(API_BASE_URL);
            if (!response.ok) {
                throw new Error('Erro ao buscar notícias para edição: ' + response.statusText);
            }
            const news = await response.json();
            const item = news.find(n => n.idnoticia == id);

            if (!item) {
                alert('Notícia não encontrada para edição.');
                return;
            }

            // Preenche o formulário
            newsIdInput.value = item.idnoticia;
            tituloInput.value = item.titulo;
            linkInput.value = item.link;
            postagemInput.value = formatDateForInput(item.postagem);
            exibirInput.checked = item.exibir;
            
            // Informação sobre a imagem atual
            if (item.image) {
                currentImageInfo.innerHTML = `Imagem atual: <a href="http://localhost:3000${item.image}" target="_blank">${item.image.split('/').pop()}</a>. Para manter, não selecione um novo arquivo.`;
            } else {
                currentImageInfo.textContent = 'Nenhuma imagem atual.';
            }

            // Altera o botão de submissão e exibe o botão de cancelar
            submitButton.textContent = 'Salvar Alterações';
            cancelButton.style.display = 'inline-block';

            // Rola para o formulário
            document.getElementById('form-section').scrollIntoView({ behavior: 'smooth' });

        } catch (error) {
            console.error('Erro ao carregar notícia para edição:', error);
            alert('Não foi possível carregar a notícia para edição.');
        }
    }

    // 4. Event Listeners

    // Submissão do formulário (Criação ou Edição)
    newsForm.addEventListener('submit', handleSubmit);

    // Cancelar edição
    cancelButton.addEventListener('click', resetForm);

    // Delegação de eventos para os botões de Editar e Excluir
    newsTableBody.addEventListener('click', (event) => {
        const target = event.target;
        const id = target.dataset.id;

        if (target.classList.contains('edit-btn')) {
            editNews(id);
        } else if (target.classList.contains('delete-btn')) {
            deleteNews(id);
        }
    });

    // 5. Inicialização
    fetchNews();
});
